# CodeClauseInternship_BasicOnlineResume
Technologies - HTML & CSS
IDE - Visual Studio Code
